class sach:
    def __init__(self,ma_s , ten_s , gia_s,):
        self.ma_s = ma_s
        self.ten_s = ten_s
        self.gia_s = gia_s
       
    
    def nhap(dssach):
        n = int(input('nhap so luong sach: '))
        for i in range(n):
            ma_s = input('nhap mã sách: ' + str(i+1)+':')
            gia_s = int(input('nhap giá sách: '+ str(i+1)+':'))
            ten_s = str(input('nhap ten sách : '+ str(i+1)+':'))
            sach = sach(ma_s,ten_s,gia_s)
            dssach.append(sach)

    def xuat(dssach):
        for sach in dssach:
            print('ma sach: ', sach.masach)
            print('ten sach: ', sach.ten)
            print('gia sách : ', sach.gia)

    


a = sach('','','')
print(a.nhap())
print(a.xuat())