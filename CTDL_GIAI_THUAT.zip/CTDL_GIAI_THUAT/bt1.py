def bt1_tuyen_tinh(ds , so):
    right = len(ds)
    for i in range(0,right):
        if (ds[i]) == so:
            return i
    return -1

ds = [2,4,1,5,7,3,-1,-99,15,50,70]
so = 3
tinh = bt1_tuyen_tinh(ds,so)
print('vị trí cần tìm là : ', tinh)

# nhị phân
import math
def bt1_nhi_phan(ds,key):
    mid = 0
    step = 0
    end = len(ds)
    start = 0 
    while start <= end:
        step +=1
        mid = (start + end) // 2

        if ds[mid] == key:
            return mid
        
        if ds[mid] > key:
            end = mid - 1
        else:
            start = mid +1
    return -1

ds = [2,4,1,5,7,3,-1,15,50,70]
key = 50
print('vị trí cần tìm là : ', bt1_nhi_phan(ds,key))