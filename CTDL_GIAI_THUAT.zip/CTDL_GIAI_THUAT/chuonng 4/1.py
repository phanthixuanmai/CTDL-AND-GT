thislist = ["hanoi", "saigon", "danang", "nhatrang", "cantho"]
print(thislist)
thislist.insert(2, "cantho") #insert
print(thislist)
thislist.insert(3, "Hue")
print(thislist)
thislist = ["hanoi", "saigon", "danang", "nhatrang"]
thislist.pop(2) #pop
thislist = ["hanoi", "saigon", "danang", "nhatrang", "cantho"]
thislist.sort()
print(thislist)
thislist = [100, 15, 50, 65, 82, 23]
thislist.sort() #sort
print(thislist)
list1 = ['data analytics', 'data science', 'data structures and algorithms', 2020, 2021]
list2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print ("list1[1]: ", list1[1])
print ("list2[2:8]: ", list2[2:8])



print('1.2')

class Node:
    def __init__(self, data):
        self.data = data # data
        self.next = None # Initialize next as null
    class LinkedList:
            def __init__(self):
                self.head = None
            def printList(self):
                temp = self.head
                while (temp):
                    class Node:
                        def __init__(self, data):
                            self.data = data # data
                            self.next = None # Initialize next as null  
                            class LinkedList:
                                def __init__(self):
                                    self.head = None
                                    def printList(self):
                                        temp = self.head
                                        while (temp):
                                            print (temp.data)
                                            temp = temp.next
                                            if __name__=='__main__':
                                                llist = LinkedList()
                                                llist.head = Node(10)
                                                second = Node(11)
                                                third = Node(12)
                                                llist.head.next = second; # Link first with second
                                                second.next = third; # Link second with the third 
                                                llist.printList()








