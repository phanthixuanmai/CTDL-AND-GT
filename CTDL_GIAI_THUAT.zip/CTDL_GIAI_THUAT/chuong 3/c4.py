'''l = ['hanoi', 'saigon', 'danang', 'nhatrang', 'cantho']
print(l)
l.insert(2,'cantho')
print(l)
l.insert(3,'hue')
print(l)
l = ['hanoi', 'saigon', 'danang', 'nhatrang']
l.pop(2)
print(l)

l = ['hanoi', 'saigon', 'danang', 'nhatrang']
l.sort()
print(l)
st = [100, 15, 50, 65, 82, 23]
st.sort()
print(st)
list1 = ['data analytics', 'data science', 'data structures and algorithms', 2020, 2021]
print('list[1] : ', list1[1])
list2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print ("list2[2:8]: ", list2[2:8])
'''

'''
#1.2

l = [0,2,4,10,30,15,25,60,50]
print('\n danh sach sac so')
print(l)
l2 = [4,4,'data science', 5,'for', 10,'machine learning']
print('\ndanh sach voi cac gia trij hon hop')
print(l2)'''

'''
class node:
    def __init__(self,data):
        self.data = data
        self.next = None

class linkedlist:
    def __init__(self):
        self.head = None
    
    def printl(self):
        tem = self.head
        while (tem):
            print(tem.data)
            tem = tem.next

if __name__== '__main__':
    lli = linkedlist()
    lli.head = node(10)
    second = node(11)
    third = node(12)

lli.head.next = second
second.next = third
lli.printl() '''

from collections import deque
deque()
deque([{'data': 'a'},{'data': 'b'}])
l = deque('abcd')
print(l)
l.append('h')
print(l)
l.pop()
print(l)

from collections import deque
d = deque([1,2,3,4,5,6])
print(d)
for i in d:
    print(i)

print(d.pop(),d)